const tf = require('@tensorflow/tfjs-node');

const a = tf.tensor([1, 2]);
a.print();