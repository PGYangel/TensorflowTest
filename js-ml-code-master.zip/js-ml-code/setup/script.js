import * as tf from '@tensorflow/tfjs';

const a = tf.tensor([1, 2]);
a.print();